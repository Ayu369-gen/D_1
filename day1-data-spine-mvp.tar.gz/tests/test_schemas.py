"""Schema validation tests."""
import pytest
import tempfile
import os
import json
import pandas as pd
from pathlib import Path

from app.core.db import init_db, get_connection
from app.market.prices import fetch_daily_ohlcv


class TestSchemas:
    """Tests for schema validation."""
    
    def test_articles_table_schema(self):
        """Verify articles table has required columns."""
        with tempfile.NamedTemporaryFile(delete=False, suffix='.db') as f:
            db_path = f.name
        
        try:
            db_url = f"sqlite:///{db_path}"
            init_db(db_url)
            conn = get_connection(db_url)
            cursor = conn.cursor()
            
            # Get table info
            cursor.execute("PRAGMA table_info(articles)")
            columns = {row[1]: row[2] for row in cursor.fetchall()}
            
            # Verify required columns exist
            required = {
                'id': 'INTEGER',
                'source': 'TEXT',
                'title': 'TEXT',
                'url': 'TEXT',
                'summary': 'TEXT',
                'published_at_utc': 'TEXT',
                'ingested_at_utc': 'TEXT',
                'content_hash': 'TEXT',
                'raw_payload': 'TEXT'
            }
            
            for col_name, col_type in required.items():
                assert col_name in columns, f"Column {col_name} missing"
                assert columns[col_name] == col_type, f"Column {col_name} wrong type"
            
            conn.close()
        finally:
            if os.path.exists(db_path):
                os.unlink(db_path)
    
    def test_ingest_runs_table_schema(self):
        """Verify ingest_runs table has required columns."""
        with tempfile.NamedTemporaryFile(delete=False, suffix='.db') as f:
            db_path = f.name
        
        try:
            db_url = f"sqlite:///{db_path}"
            init_db(db_url)
            conn = get_connection(db_url)
            cursor = conn.cursor()
            
            # Get table info
            cursor.execute("PRAGMA table_info(ingest_runs)")
            columns = {row[1]: row[2] for row in cursor.fetchall()}
            
            # Verify required columns exist
            required = {
                'run_id': 'TEXT',
                'job_name': 'TEXT',
                'started_at_utc': 'TEXT',
                'ended_at_utc': 'TEXT',
                'status': 'TEXT',
                'items_read': 'INTEGER',
                'items_written': 'INTEGER',
                'items_skipped': 'INTEGER',
                'error_message': 'TEXT'
            }
            
            for col_name in required.keys():
                assert col_name in columns, f"Column {col_name} missing"
            
            conn.close()
        finally:
            if os.path.exists(db_path):
                os.unlink(db_path)
    
    def test_snapshot_json_schema(self):
        """Verify snapshot JSON has required keys."""
        # Create a mock snapshot
        snapshot = {
            "date": "2026-01-30",
            "generated_at_utc": "2026-01-30T12:00:00Z",
            "news": {
                "total_articles": 0,
                "by_source": {},
                "published_at_utc_min": None,
                "published_at_utc_max": None
            },
            "prices": {
                "total_tickers": 2,
                "tickers_with_data": 0,
                "missing_tickers": ["AAPL", "MSFT"]
            }
        }
        
        # Verify required top-level keys
        assert "date" in snapshot
        assert "generated_at_utc" in snapshot
        assert "news" in snapshot
        assert "prices" in snapshot
        
        # Verify news keys
        assert "total_articles" in snapshot["news"]
        assert "by_source" in snapshot["news"]
        assert "published_at_utc_min" in snapshot["news"]
        assert "published_at_utc_max" in snapshot["news"]
        
        # Verify prices keys
        assert "total_tickers" in snapshot["prices"]
        assert "tickers_with_data" in snapshot["prices"]
        assert "missing_tickers" in snapshot["prices"]
    
    def test_prices_dataframe_schema(self):
        """Verify prices DataFrame has required columns."""
        # Create mock DataFrame
        df = pd.DataFrame({
            'ticker': ['AAPL'],
            'date': ['2026-01-30'],
            'open': [150.0],
            'high': [155.0],
            'low': [149.0],
            'close': [154.0],
            'volume': [1000000],
            'adj_close': [154.0]
        })
        
        # Verify required columns exist
        required_columns = ['ticker', 'date', 'open', 'high', 'low', 'close', 'volume']
        for col in required_columns:
            assert col in df.columns, f"Column {col} missing from prices DataFrame"
