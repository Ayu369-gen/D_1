"""Integration tests for database operations."""
import pytest
import tempfile
import os
from datetime import datetime

from app.core.db import init_db, get_connection
from app.ingest.dedupe import compute_content_hash


class TestDeduplication:
    """Integration tests for article deduplication."""
    
    def test_duplicate_url_skipped(self):
        """Verify second insert with same URL is skipped."""
        # Create temporary database
        with tempfile.NamedTemporaryFile(delete=False, suffix='.db') as f:
            db_path = f.name
        
        try:
            db_url = f"sqlite:///{db_path}"
            
            # Initialize database
            init_db(db_url)
            conn = get_connection(db_url)
            cursor = conn.cursor()
            
            # Prepare test article
            url = "http://example.com/article1"
            title = "Test Article"
            summary = "Test Summary"
            content_hash = compute_content_hash(title, summary, url)
            ingested_at = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
            
            # First insert
            cursor.execute("""
                INSERT INTO articles 
                (source, title, url, summary, published_at_utc, ingested_at_utc, content_hash, raw_payload)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, ("TestSource", title, url, summary, None, ingested_at, content_hash, "{}"))
            conn.commit()
            
            # Count articles
            cursor.execute("SELECT COUNT(*) FROM articles WHERE url = ?", (url,))
            count1 = cursor.fetchone()[0]
            assert count1 == 1
            
            # Try to insert duplicate (same URL)
            try:
                cursor.execute("""
                    INSERT INTO articles 
                    (source, title, url, summary, published_at_utc, ingested_at_utc, content_hash, raw_payload)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """, ("TestSource", "Different Title", url, summary, None, ingested_at, content_hash, "{}"))
                conn.commit()
                # If no exception, check constraint worked
                cursor.execute("SELECT COUNT(*) FROM articles WHERE url = ?", (url,))
                count2 = cursor.fetchone()[0]
                assert count2 == 1, "Duplicate URL should not create second row"
            except Exception:
                # Unique constraint violation expected
                pass
            
            conn.close()
            
        finally:
            if os.path.exists(db_path):
                os.unlink(db_path)
    
    def test_duplicate_content_hash_skipped(self):
        """Verify articles with same content hash can be detected."""
        # Create temporary database
        with tempfile.NamedTemporaryFile(delete=False, suffix='.db') as f:
            db_path = f.name
        
        try:
            db_url = f"sqlite:///{db_path}"
            
            # Initialize database
            init_db(db_url)
            conn = get_connection(db_url)
            cursor = conn.cursor()
            
            # Prepare test article
            title = "Same Content"
            summary = "Same Summary"
            content_hash = compute_content_hash(title, summary, None)
            ingested_at = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
            
            # First insert (no URL)
            cursor.execute("""
                INSERT INTO articles 
                (source, title, url, summary, published_at_utc, ingested_at_utc, content_hash, raw_payload)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, ("TestSource", title, None, summary, None, ingested_at, content_hash, "{}"))
            conn.commit()
            
            # Check if content_hash exists
            cursor.execute("SELECT COUNT(*) FROM articles WHERE content_hash = ?", (content_hash,))
            count = cursor.fetchone()[0]
            assert count == 1
            
            # Application logic should skip second insert based on content_hash query
            # This test verifies we can detect duplicate content_hash
            cursor.execute("SELECT id FROM articles WHERE content_hash = ?", (content_hash,))
            existing = cursor.fetchone()
            assert existing is not None, "Should be able to find article by content_hash"
            
            conn.close()
            
        finally:
            if os.path.exists(db_path):
                os.unlink(db_path)
