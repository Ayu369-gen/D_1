"""Tests for Day 1 Data Spine."""
import pytest
from app.ingest.dedupe import canonicalize_url, compute_content_hash


class TestURLCanonicalization:
    """Tests for URL canonicalization."""
    
    def test_removes_utm_parameters(self):
        """Verify utm_* parameters are removed."""
        url = "https://example.com/article?utm_source=twitter&utm_medium=social&id=123"
        result = canonicalize_url(url)
        assert "utm_source" not in result
        assert "utm_medium" not in result
        assert "id=123" in result
    
    def test_preserves_other_parameters(self):
        """Verify non-utm parameters are preserved."""
        url = "https://example.com/page?ref=home&page=2&utm_campaign=test"
        result = canonicalize_url(url)
        assert "ref=home" in result
        assert "page=2" in result
        assert "utm_campaign" not in result
    
    def test_trims_whitespace(self):
        """Verify whitespace is trimmed."""
        url = "  https://example.com/test  "
        result = canonicalize_url(url)
        assert result == "https://example.com/test"
    
    def test_handles_no_query_params(self):
        """Verify URLs without query params work."""
        url = "https://example.com/article"
        result = canonicalize_url(url)
        assert result == url
    
    def test_handles_empty_string(self):
        """Verify empty strings don't crash."""
        result = canonicalize_url("")
        assert result == ""


class TestContentHash:
    """Tests for content hashing."""
    
    def test_hash_consistency(self):
        """Verify same inputs produce same hash."""
        hash1 = compute_content_hash("Title", "Summary", "http://example.com")
        hash2 = compute_content_hash("Title", "Summary", "http://example.com")
        assert hash1 == hash2
    
    def test_hash_uniqueness(self):
        """Verify different inputs produce different hashes."""
        hash1 = compute_content_hash("Title1", "Summary", "http://example.com")
        hash2 = compute_content_hash("Title2", "Summary", "http://example.com")
        assert hash1 != hash2
    
    def test_handles_none_values(self):
        """Verify None values are handled."""
        hash_result = compute_content_hash(None, None, None)
        assert isinstance(hash_result, str)
        assert len(hash_result) == 64  # SHA256 hex digest length
