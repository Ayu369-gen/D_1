"""Price fetching job for Day 1 Data Spine."""
import argparse
from pathlib import Path

from app.core.config import load_settings
from app.core.logger import get_logger
from app.market.prices import fetch_daily_ohlcv

logger = get_logger(__name__)


def fetch_prices(start: str, end: str) -> None:
    """Fetch daily prices and save to parquet.
    
    Args:
        start: Start date (YYYY-MM-DD)
        end: End date (YYYY-MM-DD)
    """
    config = load_settings()
    tickers = config['tickers']
    prices_path = config['storage']['prices_path']
    
    logger.info("Starting price fetch", start=start, end=end, tickers=tickers)
    
    # Fetch OHLCV data
    df = fetch_daily_ohlcv(tickers, start, end)
    
    # Ensure output directory exists
    Path(prices_path).parent.mkdir(parents=True, exist_ok=True)
    
    # Save to parquet
    df.to_parquet(prices_path, index=False, engine='pyarrow')
    
    logger.info("Prices saved successfully", path=prices_path, rows=len(df))


def main():
    """CLI entry point."""
    parser = argparse.ArgumentParser(description='Fetch daily price data')
    parser.add_argument('--start', required=True, help='Start date (YYYY-MM-DD)')
    parser.add_argument('--end', required=True, help='End date (YYYY-MM-DD)')
    args = parser.parse_args()
    
    fetch_prices(args.start, args.end)


if __name__ == "__main__":
    main()
