"""Daily snapshot builder for Day 1 Data Spine."""
import argparse
import json
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional
import pandas as pd

from app.core.config import load_settings
from app.core.db import get_connection
from app.core.logger import get_logger

logger = get_logger(__name__)


def build_snapshot(date: str) -> None:
    """Build daily snapshot JSON for observability.
    
    Args:
        date: Date for snapshot (YYYY-MM-DD)
    """
    config = load_settings()
    snapshots_dir = config['storage']['snapshots_dir']
    
    logger.info("Building snapshot", date=date)
    
    # Build snapshot data
    snapshot = _build_snapshot_data(date, config)
    
    # Ensure output directory exists
    Path(snapshots_dir).mkdir(parents=True, exist_ok=True)
    
    # Write snapshot file
    output_path = Path(snapshots_dir) / f"{date}.json"
    with open(output_path, 'w') as f:
        json.dump(snapshot, f, indent=2)
    
    logger.info("Snapshot created", path=str(output_path))


def _build_snapshot_data(date: str, config: Dict[str, Any]) -> Dict[str, Any]:
    """Build snapshot data structure.
    
    Args:
        date: Date for snapshot (YYYY-MM-DD)
        config: Application configuration
        
    Returns:
        Snapshot dict matching exact contract
    """
    # Define UTC window for the date
    window_start = f"{date}T00:00:00Z"
    window_end = f"{date}T23:59:59Z"
    
    # Get news statistics
    news_stats = _get_news_stats(window_start, window_end)
    
    # Get price statistics
    price_stats = _get_price_stats(date, config)
    
    # Build snapshot
    snapshot = {
        "date": date,
        "generated_at_utc": datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"),
        "news": news_stats,
        "prices": price_stats
    }
    
    return snapshot


def _get_news_stats(window_start: str, window_end: str) -> Dict[str, Any]:
    """Get news statistics for date window.
    
    Args:
        window_start: Window start timestamp (ISO8601)
        window_end: Window end timestamp (ISO8601)
        
    Returns:
        News statistics dict
    """
    conn = get_connection()
    cursor = conn.cursor()
    
    # Query articles in window
    # Include if published_at_utc is in window, or if null, ingested_at_utc is in window
    cursor.execute("""
        SELECT source, published_at_utc
        FROM articles
        WHERE (published_at_utc >= ? AND published_at_utc <= ?)
           OR (published_at_utc IS NULL AND ingested_at_utc >= ? AND ingested_at_utc <= ?)
    """, (window_start, window_end, window_start, window_end))
    
    articles = cursor.fetchall()
    conn.close()
    
    # Count total and by source
    total_articles = len(articles)
    by_source = {}
    published_dates = []
    
    for article in articles:
        source = article['source']
        by_source[source] = by_source.get(source, 0) + 1
        
        if article['published_at_utc']:
            published_dates.append(article['published_at_utc'])
    
    # Find min/max published dates
    published_at_utc_min = min(published_dates) if published_dates else None
    published_at_utc_max = max(published_dates) if published_dates else None
    
    return {
        "total_articles": total_articles,
        "by_source": by_source,
        "published_at_utc_min": published_at_utc_min,
        "published_at_utc_max": published_at_utc_max
    }


def _get_price_stats(date: str, config: Dict[str, Any]) -> Dict[str, Any]:
    """Get price statistics for date.
    
    Args:
        date: Date to check (YYYY-MM-DD)
        config: Application configuration
        
    Returns:
        Price statistics dict
    """
    prices_path = config['storage']['prices_path']
    configured_tickers = config['tickers']
    
    # Try to load prices file
    try:
        df = pd.read_parquet(prices_path)
        
        # Filter to specific date
        date_df = df[df['date'] == date]
        
        # Get tickers with data
        tickers_with_data = date_df['ticker'].unique().tolist()
        
        # Find missing tickers
        missing_tickers = [t for t in configured_tickers if t not in tickers_with_data]
        
        return {
            "total_tickers": len(configured_tickers),
            "tickers_with_data": len(tickers_with_data),
            "missing_tickers": missing_tickers
        }
        
    except FileNotFoundError:
        # No prices file exists yet
        return {
            "total_tickers": len(configured_tickers),
            "tickers_with_data": 0,
            "missing_tickers": configured_tickers
        }
    except Exception as e:
        logger.warning(f"Failed to load prices", error=str(e))
        return {
            "total_tickers": len(configured_tickers),
            "tickers_with_data": 0,
            "missing_tickers": configured_tickers
        }


def main():
    """CLI entry point."""
    parser = argparse.ArgumentParser(description='Build daily snapshot')
    parser.add_argument('--date', required=True, help='Date for snapshot (YYYY-MM-DD)')
    args = parser.parse_args()
    
    build_snapshot(args.date)


if __name__ == "__main__":
    main()
