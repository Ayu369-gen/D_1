"""News ingestion job for Day 1 Data Spine."""
import argparse
import uuid
from datetime import datetime
from typing import Dict, List, Any
import sqlite3

from app.core.config import load_settings
from app.core.db import get_connection, init_db
from app.core.logger import get_logger
from app.ingest.rss_client import fetch_rss_feed
from app.ingest.normalizer import normalize_entry
from app.ingest.dedupe import canonicalize_url, compute_content_hash

logger = get_logger(__name__)


def ingest_news(date: str) -> None:
    """Ingest news from configured RSS feeds.
    
    Args:
        date: Date string (YYYY-MM-DD) - used for snapshot logic only
    """
    config = load_settings()
    
    # Initialize database
    init_db()
    
    # Create run record
    run_id = str(uuid.uuid4())
    started_at = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
    
    conn = get_connection()
    cursor = conn.cursor()
    
    # Insert initial run record
    cursor.execute("""
        INSERT INTO ingest_runs 
        (run_id, job_name, started_at_utc, status, items_read, items_written, items_skipped)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (run_id, 'ingest_news', started_at, 'running', 0, 0, 0))
    conn.commit()
    
    logger.info("Starting news ingestion", run_id=run_id, date=date)
    
    total_read = 0
    total_written = 0
    total_skipped = 0
    errors = []
    successful_feeds = 0
    
    # Process each RSS feed
    for feed_config in config['rss_feeds']:
        feed_name = feed_config['name']
        feed_url = feed_config['url']
        
        try:
            # Fetch feed entries
            entries = fetch_rss_feed(feed_url, feed_name)
            feed_read = len(entries)
            total_read += feed_read
            
            feed_written = 0
            feed_skipped = 0
            
            # Process each entry
            for entry in entries:
                try:
                    # Normalize entry
                    normalized = normalize_entry(feed_name, entry)
                    
                    # Canonicalize URL if present
                    if normalized['url']:
                        normalized['url'] = canonicalize_url(normalized['url'])
                    
                    # Compute content hash
                    content_hash = compute_content_hash(
                        normalized['title'],
                        normalized['summary'],
                        normalized['url']
                    )
                    
                    # Set ingested timestamp
                    ingested_at = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
                    
                    # Try to insert
                    inserted = _insert_article(cursor, normalized, content_hash, ingested_at)
                    
                    if inserted:
                        feed_written += 1
                    else:
                        feed_skipped += 1
                        
                except Exception as e:
                    logger.warning(f"Failed to process entry", 
                                 feed_name=feed_name, error=str(e))
                    feed_skipped += 1
            
            conn.commit()
            total_written += feed_written
            total_skipped += feed_skipped
            successful_feeds += 1
            
            logger.info(f"Processed feed", feed_name=feed_name, 
                       read=feed_read, written=feed_written, skipped=feed_skipped)
            
        except Exception as e:
            error_msg = f"Feed {feed_name} failed: {str(e)}"
            errors.append(error_msg)
            logger.error(f"Feed processing failed", feed_name=feed_name, error=str(e))
    
    # Determine final status
    if successful_feeds > 0:
        status = 'success'
        error_message = None if not errors else '; '.join(errors)
    else:
        status = 'fail'
        error_message = '; '.join(errors) if errors else 'All feeds failed'
    
    # Update run record
    ended_at = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
    cursor.execute("""
        UPDATE ingest_runs 
        SET ended_at_utc = ?, status = ?, items_read = ?, items_written = ?, 
            items_skipped = ?, error_message = ?
        WHERE run_id = ?
    """, (ended_at, status, total_read, total_written, total_skipped, error_message, run_id))
    
    conn.commit()
    conn.close()
    
    logger.info("News ingestion completed", run_id=run_id, status=status,
               read=total_read, written=total_written, skipped=total_skipped,
               successful_feeds=successful_feeds)


def _insert_article(cursor: sqlite3.Cursor, normalized: Dict[str, Any], 
                   content_hash: str, ingested_at: str) -> bool:
    """Insert article into database with deduplication.
    
    Args:
        cursor: Database cursor
        normalized: Normalized article data
        content_hash: Content hash
        ingested_at: Ingestion timestamp
        
    Returns:
        True if inserted, False if skipped (duplicate)
    """
    # Check if URL exists (if URL is not null)
    if normalized['url']:
        cursor.execute("SELECT id FROM articles WHERE url = ?", (normalized['url'],))
        existing = cursor.fetchone()
        
        if existing:
            # URL already exists, optionally update missing fields
            # For now, just skip
            return False
    
    # Check if content hash exists
    cursor.execute("SELECT id FROM articles WHERE content_hash = ?", (content_hash,))
    existing = cursor.fetchone()
    
    if existing:
        # Same content already exists
        return False
    
    # Insert new article
    try:
        cursor.execute("""
            INSERT INTO articles 
            (source, title, url, summary, published_at_utc, ingested_at_utc, content_hash, raw_payload)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            normalized['source'],
            normalized['title'],
            normalized['url'],
            normalized['summary'],
            normalized['published_at_utc'],
            ingested_at,
            content_hash,
            normalized['raw_payload']
        ))
        return True
    except sqlite3.IntegrityError:
        # Race condition or other constraint violation
        return False


def main():
    """CLI entry point."""
    parser = argparse.ArgumentParser(description='Ingest news from RSS feeds')
    parser.add_argument('--date', required=True, help='Date for snapshot (YYYY-MM-DD)')
    args = parser.parse_args()
    
    ingest_news(args.date)


if __name__ == "__main__":
    main()
