"""Structured logging utility for Day 1 Data Spine."""
import json
import logging
import sys
from datetime import datetime
from typing import Any, Dict


class StructuredLogger:
    """Logger that outputs structured JSON lines to stdout."""
    
    def __init__(self, name: str):
        self.name = name
        self.logger = logging.getLogger(name)
        self.logger.setLevel(logging.INFO)
        
        # Remove existing handlers
        self.logger.handlers.clear()
        
        # Add stdout handler with JSON formatter
        handler = logging.StreamHandler(sys.stdout)
        handler.setLevel(logging.INFO)
        self.logger.addHandler(handler)
    
    def _log(self, level: str, message: str, **kwargs: Any) -> None:
        """Log a structured message."""
        log_entry = {
            "timestamp": datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"),
            "level": level,
            "logger": self.name,
            "message": message,
        }
        log_entry.update(kwargs)
        print(json.dumps(log_entry))
    
    def info(self, message: str, **kwargs: Any) -> None:
        """Log info level message."""
        self._log("INFO", message, **kwargs)
    
    def warning(self, message: str, **kwargs: Any) -> None:
        """Log warning level message."""
        self._log("WARNING", message, **kwargs)
    
    def error(self, message: str, **kwargs: Any) -> None:
        """Log error level message."""
        self._log("ERROR", message, **kwargs)
    
    def debug(self, message: str, **kwargs: Any) -> None:
        """Log debug level message."""
        self._log("DEBUG", message, **kwargs)


def get_logger(name: str) -> StructuredLogger:
    """Get a structured logger instance.
    
    Args:
        name: Logger name (typically __name__)
        
    Returns:
        StructuredLogger instance
    """
    return StructuredLogger(name)
