"""Database connection and schema management for Day 1 Data Spine."""
import sqlite3
from pathlib import Path
from typing import Optional
from app.core.config import load_settings
from app.core.logger import get_logger

logger = get_logger(__name__)


def get_connection(db_url: Optional[str] = None) -> sqlite3.Connection:
    """Get SQLite database connection.
    
    Args:
        db_url: Database URL (if None, loads from config)
        
    Returns:
        SQLite connection with row factory enabled
    """
    if db_url is None:
        config = load_settings()
        db_url = config['db_url']
    
    # Extract path from sqlite:/// URL
    db_path = db_url.replace('sqlite:///', '')
    
    # Ensure directory exists
    Path(db_path).parent.mkdir(parents=True, exist_ok=True)
    
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn


def init_db(db_url: Optional[str] = None) -> None:
    """Initialize database schema if tables don't exist.
    
    Creates articles and ingest_runs tables with required indexes.
    
    Args:
        db_url: Database URL (if None, loads from config)
    """
    conn = get_connection(db_url)
    cursor = conn.cursor()
    
    logger.info("Initializing database schema")
    
    # Create articles table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS articles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source TEXT NOT NULL,
            title TEXT NOT NULL,
            url TEXT NULL,
            summary TEXT NULL,
            published_at_utc TEXT NULL,
            ingested_at_utc TEXT NOT NULL,
            content_hash TEXT NOT NULL,
            raw_payload TEXT NOT NULL
        )
    """)
    
    # Create unique index on url (where url IS NOT NULL)
    cursor.execute("""
        CREATE UNIQUE INDEX IF NOT EXISTS ux_articles_url 
        ON articles(url) WHERE url IS NOT NULL
    """)
    
    # Create other indexes
    cursor.execute("""
        CREATE INDEX IF NOT EXISTS ix_articles_published_at_utc 
        ON articles(published_at_utc)
    """)
    
    cursor.execute("""
        CREATE INDEX IF NOT EXISTS ix_articles_source 
        ON articles(source)
    """)
    
    cursor.execute("""
        CREATE INDEX IF NOT EXISTS ix_articles_content_hash 
        ON articles(content_hash)
    """)
    
    # Create ingest_runs table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS ingest_runs (
            run_id TEXT PRIMARY KEY,
            job_name TEXT NOT NULL,
            started_at_utc TEXT NOT NULL,
            ended_at_utc TEXT NULL,
            status TEXT NOT NULL,
            items_read INTEGER NOT NULL DEFAULT 0,
            items_written INTEGER NOT NULL DEFAULT 0,
            items_skipped INTEGER NOT NULL DEFAULT 0,
            error_message TEXT NULL
        )
    """)
    
    conn.commit()
    conn.close()
    
    logger.info("Database schema initialized successfully")


if __name__ == "__main__":
    # Bootstrap database
    init_db()
    print("Database initialized successfully")
