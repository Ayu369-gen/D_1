"""Configuration loader for Day 1 Data Spine."""
import os
from pathlib import Path
from typing import Any, Dict, List
import yaml


def load_settings() -> Dict[str, Any]:
    """Load and validate settings from settings.yaml.
    
    Returns:
        Dict containing configuration with validated required fields.
        
    Raises:
        FileNotFoundError: If settings.yaml doesn't exist
        ValueError: If required fields are missing or invalid
    """
    config_path = Path(__file__).parent.parent / "config" / "settings.yaml"
    
    if not config_path.exists():
        raise FileNotFoundError(f"Configuration file not found: {config_path}")
    
    with open(config_path, 'r') as f:
        config = yaml.safe_load(f)
    
    # Validate required fields
    required_fields = ['db_url', 'tickers', 'rss_feeds', 'storage']
    for field in required_fields:
        if field not in config or not config[field]:
            raise ValueError(f"Required configuration field '{field}' is missing or empty")
    
    # Validate storage subfields
    if 'prices_path' not in config['storage'] or not config['storage']['prices_path']:
        raise ValueError("Required configuration field 'storage.prices_path' is missing or empty")
    
    if 'snapshots_dir' not in config['storage'] or not config['storage']['snapshots_dir']:
        raise ValueError("Required configuration field 'storage.snapshots_dir' is missing or empty")
    
    # Auto-create directories if missing
    Path("data").mkdir(exist_ok=True)
    Path(config['storage']['snapshots_dir']).mkdir(parents=True, exist_ok=True)
    
    return config


if __name__ == "__main__":
    # Test the loader
    print(load_settings())
