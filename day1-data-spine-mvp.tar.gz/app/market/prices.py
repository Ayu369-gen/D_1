"""Market price fetching for Day 1 Data Spine."""
import pandas as pd
import yfinance as yf
from typing import List
from app.core.logger import get_logger

logger = get_logger(__name__)


def fetch_daily_ohlcv(tickers: List[str], start: str, end: str) -> pd.DataFrame:
    """Fetch daily OHLCV data for given tickers.
    
    Args:
        tickers: List of ticker symbols
        start: Start date (YYYY-MM-DD)
        end: End date (YYYY-MM-DD)
        
    Returns:
        DataFrame with columns: ticker, date, open, high, low, close, volume, adj_close
        
    Raises:
        Exception: If all tickers fail to fetch
    """
    logger.info("Fetching daily OHLCV", tickers=tickers, start=start, end=end)
    
    all_data = []
    failed_tickers = []
    
    for ticker in tickers:
        try:
            logger.info(f"Fetching ticker", ticker=ticker)
            
            # Fetch data from yfinance
            ticker_obj = yf.Ticker(ticker)
            df = ticker_obj.history(start=start, end=end, auto_adjust=False)
            
            if df.empty:
                logger.warning(f"No data returned for ticker", ticker=ticker)
                failed_tickers.append(ticker)
                continue
            
            # Reset index to get date as column
            df = df.reset_index()
            
            # Normalize column names
            df = df.rename(columns={
                'Date': 'date',
                'Open': 'open',
                'High': 'high',
                'Low': 'low',
                'Close': 'close',
                'Volume': 'volume',
                'Adj Close': 'adj_close'
            })
            
            # Convert date to string format (YYYY-MM-DD)
            df['date'] = pd.to_datetime(df['date']).dt.strftime('%Y-%m-%d')
            
            # Add ticker column
            df['ticker'] = ticker
            
            # Select required columns in exact order
            df = df[['ticker', 'date', 'open', 'high', 'low', 'close', 'volume', 'adj_close']]
            
            all_data.append(df)
            logger.info(f"Fetched ticker successfully", ticker=ticker, rows=len(df))
            
        except Exception as e:
            logger.error(f"Failed to fetch ticker", ticker=ticker, error=str(e))
            failed_tickers.append(ticker)
    
    if not all_data:
        raise Exception(f"All tickers failed to fetch: {failed_tickers}")
    
    if failed_tickers:
        logger.warning(f"Some tickers failed", failed=failed_tickers)
    
    # Combine all data
    result = pd.concat(all_data, ignore_index=True)
    
    logger.info("Fetch completed", total_rows=len(result), 
               successful_tickers=len(all_data), failed_tickers=len(failed_tickers))
    
    return result
