"""RSS feed client for Day 1 Data Spine."""
from typing import List, Dict, Any
import feedparser
from app.core.logger import get_logger

logger = get_logger(__name__)


def fetch_rss_feed(feed_url: str, feed_name: str) -> List[Dict[str, Any]]:
    """Fetch and parse RSS feed.
    
    Args:
        feed_url: URL of the RSS feed
        feed_name: Name of the feed for logging
        
    Returns:
        List of raw feed entries
        
    Raises:
        Exception: If feed cannot be fetched or parsed
    """
    logger.info(f"Fetching RSS feed", feed_name=feed_name, feed_url=feed_url)
    
    try:
        feed = feedparser.parse(feed_url)
        
        if feed.bozo:
            logger.warning(f"Feed parsing warning", feed_name=feed_name, 
                         error=str(feed.bozo_exception))
        
        entries = feed.entries
        logger.info(f"Fetched RSS entries", feed_name=feed_name, count=len(entries))
        
        return entries
        
    except Exception as e:
        logger.error(f"Failed to fetch RSS feed", feed_name=feed_name, error=str(e))
        raise
