"""RSS entry normalizer for Day 1 Data Spine."""
import json
from datetime import datetime
from typing import Dict, Any, Optional
from email.utils import parsedate_to_datetime


def normalize_entry(source: str, entry: Dict[str, Any]) -> Dict[str, Any]:
    """Normalize RSS entry to standard format.
    
    Args:
        source: Feed source name
        entry: Raw RSS entry from feedparser
        
    Returns:
        Normalized article dict with exact contract fields:
        - source: str
        - title: str
        - url: str|null
        - summary: str|null
        - published_at_utc: ISO8601 string with Z suffix|null
        - raw_payload: JSON string
    """
    # Extract title
    title = entry.get('title', '').strip() or 'Untitled'
    
    # Extract URL
    url = entry.get('link', '').strip() or None
    
    # Extract summary (try multiple fields)
    summary = (
        entry.get('summary', '').strip() or 
        entry.get('description', '').strip() or 
        None
    )
    
    # Extract and normalize published date
    published_at_utc = None
    if 'published' in entry:
        published_at_utc = _parse_date(entry['published'])
    elif 'updated' in entry:
        published_at_utc = _parse_date(entry['updated'])
    elif 'published_parsed' in entry and entry['published_parsed']:
        try:
            dt = datetime(*entry['published_parsed'][:6])
            published_at_utc = dt.strftime("%Y-%m-%dT%H:%M:%SZ")
        except:
            pass
    
    # Store raw payload as JSON string
    raw_payload = json.dumps(entry)
    
    return {
        "source": source,
        "title": title,
        "url": url,
        "summary": summary,
        "published_at_utc": published_at_utc,
        "raw_payload": raw_payload
    }


def _parse_date(date_str: str) -> Optional[str]:
    """Parse date string to UTC ISO8601 with Z suffix.
    
    Args:
        date_str: Date string in various formats
        
    Returns:
        ISO8601 string with Z suffix or None if unparseable
    """
    try:
        # Try RFC 2822 format (common in RSS)
        dt = parsedate_to_datetime(date_str)
        # Convert to UTC
        dt_utc = dt.astimezone(datetime.now().astimezone().tzinfo).astimezone()
        return dt_utc.strftime("%Y-%m-%dT%H:%M:%SZ")
    except:
        pass
    
    try:
        # Try ISO format
        dt = datetime.fromisoformat(date_str.replace('Z', '+00:00'))
        return dt.strftime("%Y-%m-%dT%H:%M:%SZ")
    except:
        pass
    
    return None
