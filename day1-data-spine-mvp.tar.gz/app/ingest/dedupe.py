"""Deduplication utilities for Day 1 Data Spine."""
import hashlib
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse
from typing import Optional


def canonicalize_url(url: str) -> str:
    """Canonicalize URL by removing utm_* parameters and trimming whitespace.
    
    Args:
        url: Original URL
        
    Returns:
        Canonicalized URL with utm_* params removed and whitespace trimmed
    """
    if not url:
        return url
    
    # Trim whitespace
    url = url.strip()
    
    try:
        # Parse URL
        parsed = urlparse(url)
        
        # Parse query parameters
        query_params = parse_qs(parsed.query, keep_blank_values=True)
        
        # Remove utm_* parameters
        filtered_params = {
            key: value 
            for key, value in query_params.items() 
            if not key.startswith('utm_')
        }
        
        # Rebuild query string
        new_query = urlencode(filtered_params, doseq=True)
        
        # Rebuild URL
        new_parsed = parsed._replace(query=new_query)
        canonicalized = urlunparse(new_parsed)
        
        return canonicalized
        
    except Exception:
        # If parsing fails, just return trimmed URL
        return url


def compute_content_hash(title: Optional[str], summary: Optional[str], url: Optional[str]) -> str:
    """Compute SHA256 hash of article content.
    
    Hash is computed as: sha256((title or "") + "||" + (summary or "") + "||" + (url or ""))
    
    Args:
        title: Article title
        summary: Article summary
        url: Article URL
        
    Returns:
        Hex digest of SHA256 hash
    """
    content = f"{title or ''}||{summary or ''}||{url or ''}"
    return hashlib.sha256(content.encode('utf-8')).hexdigest()
